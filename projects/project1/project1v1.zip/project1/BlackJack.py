from BlackJackGame import BlackJackGame

def main():
    game = BlackJackGame()
    game.play()



if __name__ == '__main__':
    main()
